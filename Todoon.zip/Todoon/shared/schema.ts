import { pgTable, text, serial, integer, boolean, timestamp, varchar, jsonb, index } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Session storage table for express-session
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

export const tags = pgTable("tags", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  color: text("color").default("#6b7280").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  completed: boolean("completed").default(false).notNull(),
  dueDate: text("due_date"), // Store as ISO string
  description: text("description"), // Task description
  tags: text("tags").array().default([]).notNull(), // Array of tag strings
  createdAt: timestamp("created_at").defaultNow().notNull(),
  userId: integer("user_id").notNull(),
  parentTaskId: integer("parent_task_id"),
  isSubtask: boolean("is_subtask").default(false).notNull(),
});



// Note: Relations are optional for basic CRUD operations
// They are commented out to avoid circular reference issues
// export const tasksRelations = relations(tasks, ({ one, many }) => ({
//   user: one(users, {
//     fields: [tasks.userId],
//     references: [users.id],
//   }),
//   parent: one(tasks, {
//     fields: [tasks.parentTaskId],
//     references: [tasks.id],
//     relationName: "parentChild",
//   }),
//   children: many(tasks, {
//     relationName: "parentChild",
//   }),
// }));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTagSchema = createInsertSchema(tags).pick({
  name: true,
  color: true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  completed: true,
  dueDate: true,
  description: true,
  tags: true,
  parentTaskId: true,
});



export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertTag = z.infer<typeof insertTagSchema>;
export type Tag = typeof tags.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

