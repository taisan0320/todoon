import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Check, Calendar, Hash, Edit2, Trash2, CheckCircle2, ChevronDown, ChevronRight, Sparkles, Tags, Plus, X, ChevronUp, LogOut, ArrowUpDown, ArrowUp, ArrowDown, Sun } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { type Task, type Tag } from "@shared/schema";

type ViewType = "inbox" | "today" | "tomorrow" | "week";

// SubtaskList component
function SubtaskList({ 
  taskId, 
  newSubtaskTitle, 
  setNewSubtaskTitle, 
  addSubtask, 
  createSubtaskMutation 
}: { 
  taskId: number;
  newSubtaskTitle: {[key: number]: string};
  setNewSubtaskTitle: React.Dispatch<React.SetStateAction<{[key: number]: string}>>;
  addSubtask: (parentTaskId: number) => void;
  createSubtaskMutation: any;
}) {
  const queryClient = useQueryClient();
  const [isSubtaskComposing, setIsSubtaskComposing] = useState(false);
  
  const { data: subtasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks", taskId, "subtasks"],
    queryFn: () => fetch(`/api/tasks/${taskId}/subtasks`).then(res => res.json()),
  });

  const updateSubtaskMutation = useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: Partial<Task> }) =>
      fetch(`/api/tasks/${id}`, {
        method: "PATCH",
        body: JSON.stringify(updates),
        headers: { "Content-Type": "application/json" },
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId, "subtasks"] });
    },
  });

  const toggleSubtaskComplete = (subtaskId: number) => {
    const subtask = subtasks.find(s => s.id === subtaskId);
    if (subtask) {
      updateSubtaskMutation.mutate({
        id: subtaskId,
        updates: { completed: !subtask.completed }
      });
    }
  };

  const handleSubtaskKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey && !isSubtaskComposing) {
      e.preventDefault();
      addSubtask(taskId);
    }
  };

  const handleSubtaskCompositionStart = () => {
    setIsSubtaskComposing(true);
  };

  const handleSubtaskCompositionEnd = () => {
    setIsSubtaskComposing(false);
  };

  return (
    <div className="ml-9 mt-2 pl-4 border-l-2 border-notion-gray-100">
      {subtasks.map((subtask) => (
        <div key={subtask.id} className="flex items-center space-x-3 py-2">
          <div
            onClick={() => toggleSubtaskComplete(subtask.id)}
            className={`w-4 h-4 border-2 rounded-md cursor-pointer flex items-center justify-center transition-colors duration-150 ${
              updateSubtaskMutation.isPending ? "opacity-50 cursor-wait" : ""
            } ${
              subtask.completed
                ? "bg-notion-gray-800 border-notion-gray-800"
                : "border-notion-gray-300 hover:border-notion-gray-600"
            }`}
          >
            {subtask.completed && <Check className="text-white w-2.5 h-2.5" />}
          </div>
          <span
            className={`text-sm ${
              subtask.completed
                ? "text-notion-gray-500 line-through"
                : "text-notion-gray-700"
            }`}
          >
            {subtask.title}
          </span>
        </div>
      ))}
      
      <div className="mt-3 flex items-center space-x-2">
        <Input
          value={newSubtaskTitle[taskId] || ""}
          onChange={(e) => setNewSubtaskTitle(prev => ({ ...prev, [taskId]: e.target.value }))}
          onKeyDown={handleSubtaskKeyDown}
          onCompositionStart={handleSubtaskCompositionStart}
          onCompositionEnd={handleSubtaskCompositionEnd}
          placeholder="サブタスクを追加..."
          className="text-sm border-none shadow-none p-0 h-auto bg-transparent focus-visible:ring-0 text-notion-gray-600"
          disabled={createSubtaskMutation.isPending}
        />
        <Button
          onClick={() => addSubtask(taskId)}
          disabled={!newSubtaskTitle[taskId]?.trim() || createSubtaskMutation.isPending}
          variant="ghost"
          size="sm"
          className="h-6 px-2 text-xs text-notion-gray-500 hover:text-notion-gray-700"
        >
          追加
        </Button>
      </div>
    </div>
  );
}

export default function Home() {
  const [location, setLocation] = useLocation();
  
  // Initialize view based on URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  const initialView = urlParams.get('view') === 'today' ? 'today' : 'inbox';
  const [currentView, setCurrentView] = useState<ViewType>(initialView);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDueDate, setNewTaskDueDate] = useState(
    initialView === 'today' ? new Date().toISOString().split('T')[0] : ""
  );
  const [newTaskTags, setNewTaskTags] = useState("");
  const [isComposing, setIsComposing] = useState(false);

  // Update due date when view changes
  useEffect(() => {
    if (currentView === 'today' && !newTaskDueDate) {
      setNewTaskDueDate(new Date().toISOString().split('T')[0]);
    }
  }, [currentView, newTaskDueDate]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState<{[key: number]: string}>({});
  const [expandedTasks, setExpandedTasks] = useState<Set<number>>(new Set());
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingTask, setDeletingTask] = useState<Task | null>(null);
  const [taskDetailModal, setTaskDetailModal] = useState<Task | null>(null);
  const [showTagManager, setShowTagManager] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  const [newTagName, setNewTagName] = useState("");
  const [newTagColor, setNewTagColor] = useState("#6b7280");
  const [showNewTaskTagDropdown, setShowNewTaskTagDropdown] = useState(false);
  const [showEditTaskTagDropdown, setShowEditTaskTagDropdown] = useState(false);
  const [selectedNewTaskTags, setSelectedNewTaskTags] = useState<string[]>([]);
  
  // Task Add Dialog state
  const [showTaskAddDialog, setShowTaskAddDialog] = useState(false);
  
  // Sort state
  const [sortBy, setSortBy] = useState<"default" | "dueDate" | "tag">("default");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  const queryClient = useQueryClient();
  const { user, logout } = useAuth();

  // Fetch tasks
  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: () => fetch("/api/tasks", {
      credentials: 'include'
    }).then(res => res.json()),
    enabled: !!user, // Only fetch when user is authenticated
  });

  // Fetch tags
  const { data: tags = [] } = useQuery<Tag[]>({
    queryKey: ["/api/tags"],
    queryFn: () => fetch("/api/tags", {
      credentials: 'include'
    }).then(res => res.json()),
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: (task: Partial<Task>) =>
      fetch("/api/tasks", {
        method: "POST",
        body: JSON.stringify(task),
        headers: { "Content-Type": "application/json" },
        credentials: 'include',
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  // Create subtask mutation
  const createSubtaskMutation = useMutation({
    mutationFn: (subtask: Partial<Task>) =>
      fetch("/api/tasks", {
        method: "POST",
        body: JSON.stringify(subtask),
        headers: { "Content-Type": "application/json" },
        credentials: 'include',
      }).then(res => res.json()),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      if (variables.parentTaskId) {
        queryClient.invalidateQueries({ queryKey: ["/api/tasks", variables.parentTaskId, "subtasks"] });
      }
    },
  });

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Task> }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PUT",
        body: JSON.stringify(updates),
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Response error:', response.status, errorText);
        throw new Error(`Failed to update task: ${response.status}`);
      }
      
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        console.error('Invalid content type:', contentType);
        throw new Error('Server returned invalid response format');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      console.error('Update task error:', error);
    },
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Failed to delete task' }));
        throw new Error(errorData.error || 'Failed to delete task');
      }
      
      // Return success for 204 No Content
      if (response.status === 204) {
        return { success: true };
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      console.error('Delete task error:', error);
      // Could add toast notification here
    },
  });

  // Generate subtasks mutation
  const generateSubtasksMutation = useMutation({
    mutationFn: ({ taskId, taskTitle, tags }: { taskId: number; taskTitle: string; tags: string[] }) =>
      fetch(`/api/tasks/${taskId}/generate-subtasks`, {
        method: "POST",
        body: JSON.stringify({ taskTitle, tags }),
        headers: { "Content-Type": "application/json" },
      }).then(res => res.json()),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", variables.taskId, "subtasks"] });
    },
  });

  // Tag mutations
  const createTagMutation = useMutation({
    mutationFn: async (tag: { name: string; color: string }) => {
      return fetch("/api/tags", {
        method: "POST",
        body: JSON.stringify(tag),
        headers: { "Content-Type": "application/json" },
      }).then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tags"] });
      setNewTagName("");
      setNewTagColor("#6b7280");
    },
  });

  const updateTagMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: { name?: string; color?: string } }) => {
      return fetch(`/api/tags/${id}`, {
        method: "PUT",
        body: JSON.stringify(updates),
        headers: { "Content-Type": "application/json" },
      }).then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tags"] });
      setEditingTag(null);
    },
  });

  const deleteTagMutation = useMutation({
    mutationFn: async (id: number) => {
      return fetch(`/api/tags/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tags"] });
    },
  });

  const startEditTask = (task: Task) => {
    setEditingTask({
      ...task,
      tags: task.tags || []
    });
  };

  const getTaskDateStatus = (task: Task) => {
    if (!task.dueDate) return null;
    
    const today = new Date();
    const dueDate = new Date(task.dueDate);
    const diffDays = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return { status: "overdue", text: "期限切れ", className: "bg-red-100 text-red-700" };
    if (diffDays === 0) return { status: "today", text: "今日", className: "bg-yellow-100 text-yellow-700" };
    if (diffDays === 1) return { status: "tomorrow", text: "明日", className: "bg-blue-100 text-blue-700" };
    return null;
  };

  const addTask = () => {
    if (newTaskTitle.trim()) {
      const allTags = [...selectedNewTaskTags];
      
      // Add manual input tags if any
      if (newTaskTags.trim()) {
        const manualTags = newTaskTags
          .split(/[,\s]+/)
          .map(tag => tag.trim())
          .filter(tag => tag.length > 0)
          .map(tag => tag.startsWith('#') ? tag : `#${tag}`);
        allTags.push(...manualTags);
      }

      createTaskMutation.mutate({
        title: newTaskTitle.trim(),
        completed: false,
        dueDate: newTaskDueDate || (currentView === "today" ? new Date().toISOString().split('T')[0] : null),
        tags: allTags.filter((tag, index) => allTags.indexOf(tag) === index), // Remove duplicates
        parentTaskId: null,
      });
      
      // Reset form
      setNewTaskTitle("");
      setNewTaskDueDate("");
      setNewTaskTags("");
      setSelectedNewTaskTags([]);
      setShowTaskAddDialog(false);
    }
  };



  const addSubtask = (parentTaskId: number) => {
    const title = newSubtaskTitle[parentTaskId];
    if (title?.trim()) {
      createSubtaskMutation.mutate({
        title: title.trim(),
        completed: false,
        dueDate: null,
        tags: [],
        parentTaskId,
      });
      setNewSubtaskTitle(prev => ({ ...prev, [parentTaskId]: "" }));
    }
  };

  const toggleTaskComplete = (task: Task) => {
    updateTaskMutation.mutate({
      id: task.id,
      updates: { completed: !task.completed }
    });
  };

  const saveEditedTask = () => {
    if (editingTask) {
      updateTaskMutation.mutate({
        id: editingTask.id,
        updates: {
          title: editingTask.title,
          dueDate: editingTask.dueDate,
          tags: editingTask.tags,
          description: editingTask.description,
        }
      });
      setEditingTask(null);
    }
  };

  const deleteTask = (task: Task) => {
    deleteTaskMutation.mutate(task.id);
    setDeletingTask(null);
  };

  const generateSubtasks = (task: Task) => {
    generateSubtasksMutation.mutate({
      taskId: task.id,
      taskTitle: task.title,
      tags: task.tags || []
    });
    setExpandedTasks(prev => new Set([...Array.from(prev), task.id]));
  };

  const toggleTaskExpansion = (taskId: number) => {
    setExpandedTasks(prev => {
      const newSet = new Set(Array.from(prev));
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  // Tag management functions
  const handleCreateTag = () => {
    if (newTagName.trim()) {
      createTagMutation.mutate({
        name: newTagName.trim(),
        color: newTagColor,
      });
    }
  };

  const handleUpdateTag = (tag: Tag, updates: { name?: string; color?: string }) => {
    updateTagMutation.mutate({
      id: tag.id,
      updates,
    });
  };

  const handleDeleteTag = (tagId: number) => {
    deleteTagMutation.mutate(tagId);
  };

  const startEditingTag = (tag: Tag) => {
    setEditingTag(tag);
    setNewTagName(tag.name);
    setNewTagColor(tag.color);
  };

  // Tag selection functions
  const toggleNewTaskTag = (tagName: string) => {
    setSelectedNewTaskTags(prev => {
      const formattedTag = tagName.startsWith('#') ? tagName : `#${tagName}`;
      if (prev.includes(formattedTag)) {
        return prev.filter(t => t !== formattedTag);
      } else {
        return [...prev, formattedTag];
      }
    });
  };

  const removeNewTaskTag = (tagToRemove: string) => {
    setSelectedNewTaskTags(prev => prev.filter(tag => tag !== tagToRemove));
  };

  const toggleEditTaskTag = (tagName: string) => {
    if (!editingTask) return;
    const formattedTag = tagName.startsWith('#') ? tagName : `#${tagName}`;
    const currentTags = editingTask.tags || [];
    
    if (currentTags.includes(formattedTag)) {
      setEditingTask({
        ...editingTask,
        tags: currentTags.filter(t => t !== formattedTag)
      });
    } else {
      setEditingTask({
        ...editingTask,
        tags: [...currentTags, formattedTag]
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey && !isComposing) {
      e.preventDefault();
      addTask();
    }
  };

  const handleCompositionStart = () => {
    setIsComposing(true);
  };

  const handleCompositionEnd = () => {
    setIsComposing(false);
  };

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('.tag-dropdown-container')) {
        setShowNewTaskTagDropdown(false);
        setShowEditTaskTagDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const openTaskDetail = (task: Task) => {
    setTaskDetailModal(task);
  };

  // Calculate task counts for each view
  const getTaskCount = (viewType: ViewType) => {
    if (!Array.isArray(tasks)) return 0;
    
    return tasks.filter(task => {
      if (!task.parentTaskId && task.completed) return false;
      
      if (viewType === "inbox") {
        return !task.parentTaskId;
      } else if (viewType === "today") {
        const today = new Date().toISOString().split('T')[0];
        return !task.parentTaskId && task.dueDate === today;
      } else if (viewType === "tomorrow") {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];
        return !task.parentTaskId && task.dueDate === tomorrowStr;
      } else if (viewType === "week") {
        const today = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(today.getDate() + 1);
        const nextWeek = new Date();
        nextWeek.setDate(today.getDate() + 7);
        
        const todayStr = today.toISOString().split('T')[0];
        const tomorrowStr = tomorrow.toISOString().split('T')[0];
        const nextWeekStr = nextWeek.toISOString().split('T')[0];
        
        // 今日と明日を除外し、明後日から一週間後までのタスクを表示
        return !task.parentTaskId && task.dueDate && task.dueDate > tomorrowStr && task.dueDate <= nextWeekStr;
      }
      return !task.parentTaskId;
    }).length;
  };

  const filteredTasks = Array.isArray(tasks) ? tasks.filter(task => {
    if (!task.parentTaskId && task.completed) return false;
    
    if (currentView === "inbox") {
      return !task.parentTaskId;
    } else if (currentView === "today") {
      const today = new Date().toISOString().split('T')[0];
      return !task.parentTaskId && task.dueDate === today;
    } else if (currentView === "tomorrow") {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];
      return !task.parentTaskId && task.dueDate === tomorrowStr;
    } else if (currentView === "week") {
      const today = new Date();
      const tomorrow = new Date();
      tomorrow.setDate(today.getDate() + 1);
      const nextWeek = new Date();
      nextWeek.setDate(today.getDate() + 7);
      
      const todayStr = today.toISOString().split('T')[0];
      const tomorrowStr = tomorrow.toISOString().split('T')[0];
      const nextWeekStr = nextWeek.toISOString().split('T')[0];
      
      // 今日と明日を除外し、明後日から一週間後までのタスクを表示
      return !task.parentTaskId && task.dueDate && task.dueDate > tomorrowStr && task.dueDate <= nextWeekStr;
    }
    return !task.parentTaskId;
  }).sort((a, b) => {
    // 一週間ビューでは常に日付順（昇順）でソート
    if (currentView === "week") {
      const dateA = a.dueDate ? new Date(a.dueDate).getTime() : Infinity;
      const dateB = b.dueDate ? new Date(b.dueDate).getTime() : Infinity;
      return dateA - dateB;
    }
    
    // Apply sorting logic for other views
    if (sortBy === "dueDate") {
      const dateA = a.dueDate ? new Date(a.dueDate).getTime() : Infinity;
      const dateB = b.dueDate ? new Date(b.dueDate).getTime() : Infinity;
      
      if (sortOrder === "asc") {
        return dateA - dateB;
      } else {
        return dateB - dateA;
      }
    } else if (sortBy === "tag") {
      const tagA = a.tags && a.tags.length > 0 ? a.tags[0].toLowerCase() : "";
      const tagB = b.tags && b.tags.length > 0 ? b.tags[0].toLowerCase() : "";
      
      if (sortOrder === "asc") {
        return tagA.localeCompare(tagB);
      } else {
        return tagB.localeCompare(tagA);
      }
    }
    
    // Default sorting by creation order (ID)
    if (sortOrder === "asc") {
      return a.id - b.id;
    } else {
      return b.id - a.id;
    }
  }) : [];

  const handleTagInput = (value: string) => {
    if (!editingTask) return;
    
    const tags = value.split(/[,\s]+/)
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0)
      .map(tag => tag.startsWith('#') ? tag : `#${tag}`);
    
    setEditingTask({ ...editingTask, tags });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-notion-gray-50 flex items-center justify-center">
        <div className="text-notion-gray-500">読み込み中...</div>
      </div>
    );
  }



  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
          <div className="flex items-center justify-between mb-4 sm:mb-8">
            <div className="flex items-center space-x-3 sm:space-x-4 min-w-0 flex-1">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-gray-800 to-gray-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-xl sm:text-3xl font-bold text-gray-900 mb-0.5 sm:mb-1 truncate">ダッシュボード</h1>
                <p className="text-sm sm:text-base text-gray-500 hidden sm:block">今日のタスクを整理しましょう</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-3 flex-shrink-0">
              <Button 
                size="sm"
                className="bg-gray-900 text-white hover:bg-gray-800 shadow-sm px-3 sm:px-6"
                onClick={() => setShowTaskAddDialog(true)}
              >
                <Plus className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">タスクを追加</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={async () => {
                  try {
                    await logout();
                    window.location.reload();
                  } catch (error) {
                    console.error("ログアウトエラー:", error);
                  }
                }}
                className="text-gray-500 hover:text-gray-700 hover:bg-gray-50 px-2 sm:px-3"
              >
                <LogOut className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">ログアウト</span>
              </Button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="w-full overflow-x-auto scrollbar-hide px-1">
            <div className="flex space-x-1 sm:space-x-2 p-1 bg-gray-50 rounded-lg" style={{ minWidth: 'max-content' }}>
              <button
                onClick={() => setCurrentView("inbox")}
                className={`flex items-center space-x-1 sm:space-x-1.5 px-2 sm:px-3 py-2 sm:py-2.5 rounded-md text-xs sm:text-sm font-medium transition-all duration-200 whitespace-nowrap min-w-0 ${
                  currentView === "inbox"
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                }`}
              >
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${currentView === "inbox" ? "bg-gray-900" : "bg-gray-400"}`}></div>
                <span className="hidden md:inline">インボックス</span>
                <span className="md:hidden">Inbox</span>
                <span className={`px-1 sm:px-1.5 py-0.5 rounded-full text-xs font-medium flex-shrink-0 min-w-4 text-center ${
                  currentView === "inbox" ? "bg-gray-100 text-gray-700" : "bg-gray-200 text-gray-500"
                }`}>{getTaskCount("inbox")}</span>
              </button>
              
              <button
                onClick={() => setCurrentView("today")}
                className={`flex items-center space-x-1 sm:space-x-1.5 px-2 sm:px-3 py-2 sm:py-2.5 rounded-md text-xs sm:text-sm font-medium transition-all duration-200 whitespace-nowrap min-w-0 ${
                  currentView === "today"
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                }`}
              >
                <Calendar className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
                <span>今日</span>
                <span className={`px-1 sm:px-1.5 py-0.5 rounded-full text-xs font-medium flex-shrink-0 min-w-4 text-center ${
                  currentView === "today" ? "bg-gray-100 text-gray-700" : "bg-gray-200 text-gray-500"
                }`}>{getTaskCount("today")}</span>
              </button>

              <button
                onClick={() => setCurrentView("tomorrow")}
                className={`flex items-center space-x-1 sm:space-x-1.5 px-2 sm:px-3 py-2 sm:py-2.5 rounded-md text-xs sm:text-sm font-medium transition-all duration-200 whitespace-nowrap min-w-0 ${
                  currentView === "tomorrow"
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                }`}
              >
                <Sun className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
                <span>明日</span>
                <span className={`px-1 sm:px-1.5 py-0.5 rounded-full text-xs font-medium flex-shrink-0 min-w-4 text-center ${
                  currentView === "tomorrow" ? "bg-gray-100 text-gray-700" : "bg-gray-200 text-gray-500"
                }`}>{getTaskCount("tomorrow")}</span>
              </button>

              <button
                onClick={() => setCurrentView("week")}
                className={`flex items-center space-x-1 sm:space-x-1.5 px-2 sm:px-3 py-2 sm:py-2.5 rounded-md text-xs sm:text-sm font-medium transition-all duration-200 whitespace-nowrap min-w-0 ${
                  currentView === "week"
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                }`}
              >
                <Calendar className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
                <span className="hidden lg:inline">一週間</span>
                <span className="lg:hidden">1週間</span>
                <span className={`px-1 sm:px-1.5 py-0.5 rounded-full text-xs font-medium flex-shrink-0 min-w-4 text-center ${
                  currentView === "week" ? "bg-gray-100 text-gray-700" : "bg-gray-200 text-gray-500"
                }`}>{getTaskCount("week")}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      <main className="max-w-4xl mx-auto p-4 sm:p-6">
        <div className="mb-4 sm:mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1 sm:space-x-2">
              {/* Sort Controls */}
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    if (sortBy === "default") {
                      setSortBy("dueDate");
                      setSortOrder("asc");
                    } else if (sortBy === "dueDate" && sortOrder === "asc") {
                      setSortOrder("desc");
                    } else if (sortBy === "dueDate" && sortOrder === "desc") {
                      setSortBy("tag");
                      setSortOrder("asc");
                    } else if (sortBy === "tag" && sortOrder === "asc") {
                      setSortOrder("desc");
                    } else {
                      setSortBy("default");
                      setSortOrder("asc");
                    }
                  }}
                  className="text-notion-gray-600 hover:text-notion-gray-900 text-xs px-2 sm:px-3"
                >
                  {sortBy === "default" && <ArrowUpDown className="w-3 h-3 sm:mr-1" />}
                  {sortBy === "dueDate" && sortOrder === "asc" && <ArrowUp className="w-3 h-3 sm:mr-1" />}
                  {sortBy === "dueDate" && sortOrder === "desc" && <ArrowDown className="w-3 h-3 sm:mr-1" />}
                  {sortBy === "tag" && sortOrder === "asc" && <ArrowUp className="w-3 h-3 sm:mr-1" />}
                  {sortBy === "tag" && sortOrder === "desc" && <ArrowDown className="w-3 h-3 sm:mr-1" />}
                  <span className="hidden sm:inline">
                    {sortBy === "default" && "並び替え"}
                    {sortBy === "dueDate" && "日付順"}
                    {sortBy === "tag" && "タグ順"}
                  </span>
                </Button>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowTagManager(true)}
                className="text-notion-gray-600 hover:text-notion-gray-900 px-2 sm:px-3"
              >
                <Tags className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">Tags</span>
              </Button>
            </div>
          </div>
        </div>



        <div className="space-y-2 pb-24">
          {filteredTasks.map((task) => {
            return (
              <div key={task.id} className="group bg-white rounded-lg border border-notion-gray-200 p-4 hover:border-notion-gray-300 transition-colors">
                <div className="flex items-center space-x-3">
                  <div
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      toggleTaskComplete(task);
                    }}
                    className={`w-5 h-5 border-2 rounded-md cursor-pointer flex items-center justify-center transition-colors duration-150 ${
                      updateTaskMutation.isPending ? "opacity-50 cursor-wait" : ""
                    } ${
                      task.completed
                        ? "bg-notion-gray-800 border-notion-gray-800"
                        : "border-notion-gray-300 hover:border-notion-gray-600"
                    }`}
                  >
                    {task.completed && <Check className="text-white w-3 h-3" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <h3
                        onClick={() => openTaskDetail(task)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            openTaskDetail(task);
                          }
                        }}
                        tabIndex={0}
                        className={`font-medium cursor-pointer hover:text-notion-gray-600 transition-colors focus:outline-none focus:ring-2 focus:ring-notion-gray-300 rounded px-1 ${
                          task.completed ? "line-through text-notion-gray-500" : "text-notion-gray-900"
                        }`}
                      >
                        {task.title}
                      </h3>
                      {task.dueDate && (
                        <span className="text-xs text-notion-gray-500 bg-notion-gray-100 px-2 py-1 rounded-md flex-shrink-0">
                          {new Date(task.dueDate).toLocaleDateString('ja-JP', { 
                            month: 'short', 
                            day: 'numeric'
                          })}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredTasks.length === 0 && (
          <div className="text-center py-12">
            <CheckCircle2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-500 mb-2">
              {currentView === "today" ? "今日のタスクはありません" : 
               currentView === "tomorrow" ? "明日のタスクはありません" :
               currentView === "week" ? "今週のタスクはありません" : "タスクがありません"}
            </h3>
            <p className="text-gray-400">
              {currentView === "today" ? "今日は予定がありません" : 
               currentView === "tomorrow" ? "明日は予定がありません" :
               currentView === "week" ? "今週は予定がありません" : "新しいタスクを追加してください"}
            </p>
          </div>
        )}
      </main>
      {/* Task Edit Dialog */}
      <Dialog open={!!editingTask} onOpenChange={() => setEditingTask(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>タスクを編集</DialogTitle>
            <DialogDescription>
              タスクの詳細を変更できます
            </DialogDescription>
          </DialogHeader>
          {editingTask && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-notion-gray-700 mb-2 block">
                  タイトル
                </label>
                <Input
                  value={editingTask.title}
                  onChange={(e) => setEditingTask({ ...editingTask, title: e.target.value })}
                  placeholder="タスクのタイトル"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-notion-gray-700 mb-2 block">
                  説明
                </label>
                <Input
                  value={editingTask.description || ""}
                  onChange={(e) => setEditingTask({ ...editingTask, description: e.target.value })}
                  placeholder="説明を追加..."
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-notion-gray-700 mb-2 block">
                  締切日
                </label>
                <Input
                  type="date"
                  value={editingTask.dueDate || ""}
                  onChange={(e) => setEditingTask({ ...editingTask, dueDate: e.target.value })}
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-notion-gray-700 mb-2 block">
                  タグ
                </label>
                
                {/* Selected Tags Display */}
                {editingTask.tags && editingTask.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {editingTask.tags.map((tag, index) => (
                      <Badge 
                        key={index} 
                        variant="outline" 
                        className="text-xs flex items-center gap-1"
                      >
                        <Hash className="w-2 h-2" />
                        {tag.replace('#', '')}
                        <X 
                          className="w-3 h-3 cursor-pointer hover:text-red-500" 
                          onClick={() => {
                            const updatedTags = editingTask.tags?.filter((_, i) => i !== index) || [];
                            setEditingTask({ ...editingTask, tags: updatedTags });
                          }}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
                
                <div className="relative tag-dropdown-container">
                  <div className="flex space-x-2">
                    <Input
                      value=""
                      placeholder="新しいタグを入力またはドロップダウンから選択..."
                      onChange={(e) => {
                        if (e.target.value.trim()) {
                          const newTag = e.target.value.trim().startsWith('#') ? e.target.value.trim() : `#${e.target.value.trim()}`;
                          const currentTags = editingTask.tags || [];
                          if (!currentTags.includes(newTag)) {
                            setEditingTask({ ...editingTask, tags: [...currentTags, newTag] });
                          }
                          e.target.value = '';
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                          e.preventDefault();
                          const newTag = e.currentTarget.value.trim().startsWith('#') ? e.currentTarget.value.trim() : `#${e.currentTarget.value.trim()}`;
                          const currentTags = editingTask.tags || [];
                          if (!currentTags.includes(newTag)) {
                            setEditingTask({ ...editingTask, tags: [...currentTags, newTag] });
                          }
                          e.currentTarget.value = '';
                        }
                      }}
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setShowEditTaskTagDropdown(!showEditTaskTagDropdown)}
                      className="px-3"
                    >
                      {showEditTaskTagDropdown ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </Button>
                  </div>
                  
                  {/* Tag Dropdown */}
                  {showEditTaskTagDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-48 overflow-y-auto">
                      {tags.length === 0 ? (
                        <div className="p-3 text-sm text-gray-500 text-center">
                          使用可能なタグがありません
                        </div>
                      ) : (
                        tags.map((tag) => {
                          const formattedTagName = `#${tag.name}`;
                          const isSelected = editingTask.tags?.includes(formattedTagName) || false;
                          return (
                            <div
                              key={tag.id}
                              className={`flex items-center space-x-2 p-2 hover:bg-gray-50 cursor-pointer ${
                                isSelected ? 'bg-blue-50' : ''
                              }`}
                              onClick={() => toggleEditTaskTag(tag.name)}
                            >
                              <div
                                className="w-3 h-3 rounded-full flex-shrink-0"
                                style={{ backgroundColor: tag.color }}
                              />
                              <span className="text-sm flex-1">{tag.name}</span>
                              {isSelected && <Check className="w-4 h-4 text-blue-500" />}
                            </div>
                          );
                        })
                      )}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setEditingTask(null)}>
                  キャンセル
                </Button>
                <Button onClick={saveEditedTask} className="bg-notion-gray-800 text-white hover:bg-notion-gray-700">
                  保存
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      {/* Task Detail Dialog */}
      <Dialog open={!!taskDetailModal} onOpenChange={() => setTaskDetailModal(null)}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-notion-gray-900">
              タスクの詳細
            </DialogTitle>
            <DialogDescription>
              タスクの情報とサブタスクを管理できます
            </DialogDescription>
          </DialogHeader>
          {taskDetailModal && (
            <div className="space-y-6">
              {/* Task Info Card */}
              <div className="bg-notion-gray-50 rounded-lg p-4 space-y-3">
                <div>
                  <h3 className="text-sm font-medium text-notion-gray-600 mb-1">タイトル</h3>
                  <p className="text-lg font-semibold text-notion-gray-900">{taskDetailModal.title}</p>
                </div>
                
                {taskDetailModal.description && (
                  <div>
                    <h3 className="text-sm font-medium text-notion-gray-600 mb-1">説明</h3>
                    <p className="text-notion-gray-800">{taskDetailModal.description}</p>
                  </div>
                )}
                
                {taskDetailModal.dueDate && (
                  <div>
                    <h3 className="text-sm font-medium text-notion-gray-600 mb-1">締切日</h3>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-notion-gray-500" />
                      <span className="text-notion-gray-800">
                        {new Date(taskDetailModal.dueDate).toLocaleDateString('ja-JP')}
                      </span>
                    </div>
                  </div>
                )}
                
                {taskDetailModal.tags && taskDetailModal.tags.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-notion-gray-600 mb-2">タグ</h3>
                    <div className="flex flex-wrap gap-2">
                      {taskDetailModal.tags.map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          <Hash className="w-2 h-2 mr-1" />
                          {tag.replace('#', '')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                <div>
                  <h3 className="text-sm font-medium text-notion-gray-600 mb-1">ステータス</h3>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${
                        taskDetailModal.completed ? "bg-green-500" : "bg-gray-300"
                      }`} />
                      <span className="text-notion-gray-800">
                        {taskDetailModal.completed ? "完了" : "未完了"}
                      </span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        toggleTaskComplete(taskDetailModal);
                        // モーダルの状態も更新
                        setTaskDetailModal({
                          ...taskDetailModal,
                          completed: !taskDetailModal.completed
                        });
                      }}
                      className="text-xs"
                    >
                      {taskDetailModal.completed ? "未完了にする" : "完了にする"}
                    </Button>
                  </div>
                </div>
              </div>

              {/* Subtasks Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-notion-gray-900">サブタスク</h3>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generateSubtasks(taskDetailModal)}
                      disabled={generateSubtasksMutation.isPending}
                      className="text-notion-gray-600 hover:text-notion-gray-800"
                    >
                      <Sparkles className="w-4 h-4 mr-1" />
                      AI生成
                    </Button>
                  </div>
                </div>
                
                <SubtaskList
                  taskId={taskDetailModal.id}
                  newSubtaskTitle={newSubtaskTitle}
                  setNewSubtaskTitle={setNewSubtaskTitle}
                  addSubtask={addSubtask}
                  createSubtaskMutation={createSubtaskMutation}
                />
              </div>

              <div className="flex justify-between pt-4 border-t border-notion-gray-200">
                <Button 
                  variant="outline"
                  onClick={() => {
                    setDeletingTask(taskDetailModal);
                    setTaskDetailModal(null);
                  }}
                  className="text-red-600 hover:text-red-700 border-red-200 hover:border-red-300"
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  削除
                </Button>
                
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={() => setTaskDetailModal(null)}>
                    閉じる
                  </Button>
                  <Button 
                    onClick={() => {
                      startEditTask(taskDetailModal);
                      setTaskDetailModal(null);
                    }}
                    className="bg-notion-gray-800 text-white hover:bg-notion-gray-700"
                  >
                    <Edit2 className="w-4 h-4 mr-1" />
                    編集
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deletingTask} onOpenChange={() => setDeletingTask(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              タスクを削除
            </AlertDialogTitle>
            <AlertDialogDescription>
              「{deletingTask?.title}」を削除してもよろしいですか？この操作は元に戻せません。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingTask && deleteTask(deletingTask)}
              className="bg-red-600 hover:bg-red-700"
            >
              削除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      {/* Tag Management Dialog */}
      <Dialog open={showTagManager} onOpenChange={setShowTagManager}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>タグ管理</DialogTitle>
            <DialogDescription>
              タスクで使用するタグを作成・編集・削除できます
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Create New Tag */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium">新しいタグを作成</h3>
              <div className="flex space-x-2">
                <Input
                  placeholder="タグ名"
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  className="flex-1"
                />
                <input
                  type="color"
                  value={newTagColor}
                  onChange={(e) => setNewTagColor(e.target.value)}
                  className="w-10 h-9 rounded border border-gray-300"
                />
                <Button
                  onClick={handleCreateTag}
                  disabled={!newTagName.trim() || createTagMutation.isPending}
                  size="sm"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Existing Tags */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium">既存のタグ</h3>
              <div className="max-h-60 overflow-y-auto space-y-1">
                {tags.length === 0 ? (
                  <p className="text-sm text-gray-500 py-4 text-center">
                    まだタグがありません
                  </p>
                ) : (
                  tags.map((tag) => (
                    <div key={tag.id} className="flex items-center space-x-2 p-2 border rounded">
                      {editingTag?.id === tag.id ? (
                        <>
                          <Input
                            value={newTagName}
                            onChange={(e) => setNewTagName(e.target.value)}
                            className="flex-1"
                          />
                          <input
                            type="color"
                            value={newTagColor}
                            onChange={(e) => setNewTagColor(e.target.value)}
                            className="w-8 h-8 rounded border"
                          />
                          <Button
                            onClick={() => handleUpdateTag(tag, { name: newTagName, color: newTagColor })}
                            disabled={updateTagMutation.isPending}
                            size="sm"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={() => setEditingTag(null)}
                            variant="ghost"
                            size="sm"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <div
                            className="w-4 h-4 rounded-full flex-shrink-0"
                            style={{ backgroundColor: tag.color }}
                          />
                          <span className="flex-1 text-sm">{tag.name}</span>
                          <Button
                            onClick={() => startEditingTag(tag)}
                            variant="ghost"
                            size="sm"
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={() => handleDeleteTag(tag.id)}
                            disabled={deleteTagMutation.isPending}
                            variant="ghost"
                            size="sm"
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      {/* Task Add Modal */}
      <Dialog open={showTaskAddDialog} onOpenChange={setShowTaskAddDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>新しいタスクを追加</DialogTitle>
            <DialogDescription>
              タスクの詳細を入力してください
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                タスク名
              </label>
              <Input
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                onKeyDown={handleKeyDown}
                onCompositionStart={handleCompositionStart}
                onCompositionEnd={handleCompositionEnd}
                placeholder="新しいタスクを追加..."
                className="w-full"
                autoFocus
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  締切日
                </label>
                <Input
                  type="date"
                  value={newTaskDueDate}
                  onChange={(e) => setNewTaskDueDate(e.target.value)}
                  className="text-sm w-full"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  タグ
                </label>
                
                {/* Selected Tags Display */}
                {selectedNewTaskTags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {selectedNewTaskTags.map((tag) => (
                      <Badge 
                        key={tag} 
                        variant="outline" 
                        className="text-xs flex items-center gap-1"
                      >
                        <Hash className="w-2 h-2" />
                        {tag.replace('#', '')}
                        <X 
                          className="w-3 h-3 cursor-pointer hover:text-red-500" 
                          onClick={() => removeNewTaskTag(tag)}
                        />
                      </Badge>
                    ))}
                  </div>
                )}
                
                <div className="relative">
                  <div className="flex space-x-2">
                    <Input
                      value={newTaskTags}
                      onChange={(e) => setNewTaskTags(e.target.value)}
                      placeholder="新しいタグを入力..."
                      className="text-sm flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setShowNewTaskTagDropdown(!showNewTaskTagDropdown)}
                      className="px-3"
                    >
                      {showNewTaskTagDropdown ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </Button>
                  </div>
                  
                  {/* Tag Dropdown */}
                  {showNewTaskTagDropdown && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-48 overflow-y-auto">
                      {tags.length === 0 ? (
                        <div className="p-3 text-sm text-gray-500 text-center">
                          使用可能なタグがありません
                        </div>
                      ) : (
                        tags.map((tag) => {
                          const formattedTagName = `#${tag.name}`;
                          const isSelected = selectedNewTaskTags.includes(formattedTagName);
                          return (
                            <div
                              key={tag.id}
                              className={`flex items-center space-x-2 p-2 hover:bg-gray-50 cursor-pointer ${
                                isSelected ? 'bg-blue-50' : ''
                              }`}
                              onClick={() => toggleNewTaskTag(tag.name)}
                            >
                              <div
                                className="w-3 h-3 rounded-full flex-shrink-0"
                                style={{ backgroundColor: tag.color }}
                              />
                              <span className="text-sm flex-1">{tag.name}</span>
                              {isSelected && <Check className="w-4 h-4 text-blue-500" />}
                            </div>
                          );
                        })
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="text-xs text-gray-500">
              ヒント: タグは自動的に#が付きます（例: work → #work）
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setShowTaskAddDialog(false);
                  setNewTaskTitle("");
                  setNewTaskDueDate("");
                  setNewTaskTags("");
                  setSelectedNewTaskTags([]);
                }}
              >
                キャンセル
              </Button>
              <Button
                onClick={addTask}
                disabled={!newTaskTitle.trim() || createTaskMutation.isPending}
                className="bg-gray-800 text-white hover:bg-gray-700"
              >
                追加
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}