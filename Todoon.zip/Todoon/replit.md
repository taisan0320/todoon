# TODO Application

## Overview

This is a full-stack web application built as a todo/task management system. The application uses a modern React frontend with shadcn/ui components and an Express.js backend. Currently, the application operates with in-memory storage but is configured to support PostgreSQL database integration using Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ESM modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Session Management**: Configured for connect-pg-simple (currently unused)
- **API Structure**: RESTful API with `/api` prefix

## Key Components

### Database Schema
The application defines a user schema with the following structure:
- **users table**: Contains id (serial primary key), username (unique text), and password (text)
- **Type Safety**: Uses Drizzle Zod integration for runtime validation

### Storage Layer
Currently implements an in-memory storage solution with the following interface:
- `getUser(id: number)`: Retrieve user by ID
- `getUserByUsername(username: string)`: Retrieve user by username
- `createUser(user: InsertUser)`: Create new user

### Frontend Components
- **Home Page**: Main todo application interface with task management
- **Task Management**: Create, edit, delete, and mark tasks as complete
- **Views**: Inbox and Today views for organizing tasks
- **Local Storage**: Tasks persist in browser localStorage

### UI System
- Comprehensive shadcn/ui component library
- Dark/light theme support via CSS variables
- Responsive design with mobile-first approach
- Accessible components using Radix UI primitives

## Data Flow

1. **Client Requests**: Frontend makes HTTP requests to `/api` endpoints
2. **Server Processing**: Express.js routes handle requests and interact with storage layer
3. **Data Persistence**: Currently uses in-memory storage, designed for PostgreSQL integration
4. **Response Handling**: TanStack Query manages caching and state synchronization
5. **UI Updates**: React components re-render based on query state changes

## External Dependencies

### Core Dependencies
- **Database**: Neon serverless PostgreSQL (configured but not actively used)
- **UI Components**: Radix UI ecosystem for accessible components
- **Date Handling**: date-fns for date manipulation and formatting
- **Form Validation**: React Hook Form with Hookform resolvers

### Development Dependencies
- **Build Tools**: Vite, ESBuild for production builds
- **Type Checking**: TypeScript with strict configuration
- **CSS Processing**: PostCSS with Tailwind CSS and Autoprefixer

## Deployment Strategy

### Development
- `npm run dev`: Starts development server with hot reloading
- Vite dev server proxy handles API requests to Express backend
- TypeScript checking runs separately from build process

### Production
- `npm run build`: Creates optimized production build
- Frontend builds to `dist/public` directory
- Backend bundles to `dist/index.js` using ESBuild
- `npm start`: Runs production server

### Database Operations
- `npm run db:push`: Pushes schema changes to database using Drizzle Kit
- Database configuration expects `DATABASE_URL` environment variable

## Changelog

```
Changelog:
- June 28, 2025. Initial setup
- June 28, 2025. Enhanced UI based on user feedback:
  - Moved Inbox/Today tabs to bottom navigation bar
  - Improved tag functionality to accept tags with or without # prefix
  - Completed tasks now automatically hide from view
  - Added proper spacing for bottom navigation
- June 28, 2025. Added AI-powered subtask generation:
  - Integrated OpenAI API for automatic task decomposition
  - Added expand/collapse functionality for subtask management
  - Extended database schema to support parent-child task relationships
  - Implemented subtask UI with completion tracking
  - Added monochrome design elements throughout application
- June 28, 2025. Enhanced subtask functionality:
  - Fixed OpenAI prompts to generate subtasks in Japanese
  - Removed blue button styling from bottom navigation
  - Added manual subtask input with keyboard and button controls
  - Fixed subtask ordering to display in creation sequence (ascending ID order)
- June 28, 2025. UI improvements:
  - Removed bottom navigation completely to eliminate blue button issues
  - Added top tab navigation for Inbox/Today views with clean monochrome styling
  - Updated layout spacing to accommodate new navigation placement
- June 28, 2025. Navigation and timer enhancements:
  - Moved Inbox/Today tabs from top to bottom navigation
  - Added black "Add Task" button to replace removed blue button
  - Implemented comprehensive task detail modal with Japanese UI
  - Added Pomodoro timer with 25/5/15 minute work/break cycles
  - Fixed subtask checkbox functionality with proper state management
- June 28, 2025. Task management focus and UI simplification:
  - Removed Pomodoro timer functionality per user request
  - Simplified bottom navigation to Inbox/Today tabs only
  - Enhanced default task input form with expanded date and tag fields
  - Improved UI consistency across all pages
- June 28, 2025. Deployment and database fixes:
  - Fixed server configuration for better Autoscale deployment compatibility
  - Changed from server.listen() to app.listen() for improved compatibility
  - Added comprehensive error handling for server startup
  - Added process error handlers to prevent silent failures
  - Fixed task deletion issue by handling cascading deletion of subtasks
  - Resolved foreign key constraint violations in database operations
  - Enhanced deletion functionality with database transactions for data integrity
  - Improved frontend error handling for deletion operations
- June 28, 2025. UI layout improvements:
  - Reorganized task card layout for better visual hierarchy
  - Moved date, tags, edit and delete buttons to second row in horizontal layout
  - Improved spacing and alignment of task elements
  - Enhanced readability and user experience
- June 28, 2025. Checkbox functionality fixes:
  - Fixed task completion toggle using proper HTTP PUT method
  - Added correct request headers for JSON API communication
  - Implemented event propagation prevention for checkbox clicks
  - Enhanced error handling with detailed logging for API responses
  - Resolved HTML fallback issue affecting API requests
- June 28, 2025. Final task card layout optimization:
  - Moved subtask buttons from bottom to directly under task title
  - Repositioned date/tag controls to appear after subtask controls
  - Improved visual hierarchy with proper spacing and order
  - Achieved user's ideal layout preference
- June 28, 2025. PostgreSQL認証システム実装完了:
  - ユーザー登録・ログイン・ログアウト機能を実装
  - PostgreSQLデータベースでセッション管理
  - bcryptでパスワードハッシュ化
  - すべてのタスクAPIエンドポイントに認証を追加
  - マルチユーザー対応でユーザー別タスク管理
  - 日本語インターフェースでの認証画面
  - ログイン成功後の自動タスク管理画面移行
  - 認証状態の更新処理とAPIエラーハンドリングを修正
  - タスク作成・完了・削除の全機能が正常動作を確認
  - ログアウト後のログイン画面復帰機能完成
  - 認証状態管理の改善により画面遷移問題を解決
- June 28, 2025. ヘッダーUI改善:
  - ヘッダーレイアウトを2行構成に変更
  - アプリタイトルとユーザー情報を分離して視認性向上
  - より整理されたレイアウトでユーザー体験を改善
- June 28, 2025. モーダルベース詳細表示システム実装:
  - メインインターフェースをタスク名とチェックボックスのみのシンプル表示に変更
  - すべての詳細機能（日付、タグ、編集、削除、サブタスク管理）をモーダルに集約
  - モーダル内でタスク完了状態の切り替え機能を追加
  - キーボードショートカット（Enter/Space）でモーダルを開く機能を実装
  - クリーンでフォーカスされたタスク管理UXを実現
- June 28, 2025. クイックタスク追加フローティングボタン実装:
  - 右下に常時表示されるフローティングボタンを追加
  - ワンクリックでタスク追加モーダルを開く機能
  - シンプルなタスク名入力とEnterキーでの即座追加
  - BottomNavigationの上に適切に配置
  - 素早いタスク作成のためのUX改善
- June 28, 2025. UI/UX改善:
  - タスク追加の入力欄とボタンの配置を入れ替え（入力欄を左、ボタンを右に）
  - タスクリストに下部マージン（pb-24）を追加し、底部ナビゲーションでの隠れを防止
  - スクロール時の最後のタスクまでの視認性を向上
- June 28, 2025. タスク並び替え機能実装:
  - 日付順（昇順・降順）での並び替え機能を追加
  - タグ別（昇順・降順）での並び替え機能を追加
  - デフォルト（作成順）での並び替えサポート
  - ヘッダー部分にワンクリック並び替えボタンを配置
  - 日付なしタスクは常に最後に表示される仕様
- June 28, 2025. タスクリスト日付表示機能追加:
  - タスク名の右横に締切日を表示
  - 日付が設定されていない場合は非表示
  - 日本語ロケールでの日付表示（月日形式）
  - 灰色背景のバッジスタイルで視認性向上
- June 29, 2025. ルーティーン管理機能実装:
  - 新しい「Routine」タブを底部ナビゲーションに追加
  - 曜日ごとのルーティーン登録・編集・削除機能
  - 時間設定オプション（任意）
  - ルーティーンの説明フィールド（任意）
  - 曜日別の整理されたビューで表示
  - PostgreSQLデータベースによるユーザー別データ管理
  - 完全なCRUD操作サポート（作成・読み取り・更新・削除）
- July 2, 2025. 新UIデザイン実装・タスク追加モーダル化:
  - 添付画像に基づく新しいダッシュボードスタイルUI
  - 上部に期限通知バナー（オレンジグラデーション）
  - ピル形式のナビゲーションタブ（インボックス、今日、ルーティーン、一週間）
  - ヘッダーの「タスクを追加」ボタンでモーダル表示
  - タスク追加フォーム（タスク名、締切日、タグ選択）をモーダル内に統合
  - 洗練された日本語UI（グレー系カラーパレット）
  - ルーティーン管理にフローティングボタン追加
- July 2, 2025. ナビゲーション機能強化・タスク数動的計算:
  - 「明日」ボタンを実装（Sunアイコン、明日の日付のタスクフィルタリング）
  - 「一週間」ボタンに機能追加（今日から一週間以内のタスクを表示）
  - 「ルーティーン」ボタンをヘッダー部分に移動
  - タスク数の動的計算機能実装（完了タスクを除外し、各ビューに応じた正確な数を表示）
  - 各ナビゲーションタブで実際のタスク数をリアルタイム反映
- July 3, 2025. ルーティーン機能完全削除・UI改善:
  - ルーティーン機能を完全削除（ページ、スキーマ、API、ボタン、アイコン）
  - データベーススキーマからroutinesテーブルを削除
  - 全てのルーティーン関連コードとファイルを削除
  - ヘッダーUIを大幅改善（グラデーションアイコン、洗練されたデザイン）
  - ナビゲーションタブを背景付きスタイルに変更
  - タスク管理のコア機能に集中したクリーンなUI
- July 3, 2025. モバイル最適化・レスポンシブデザイン強化:
  - ナビゲーションタブをスマホ対応に改善（横スクロール可能）
  - スマホ向け短縮ラベル実装（「インボックス」→「全て」、「一週間」→「週」）
  - ヘッダー要素のレスポンシブサイズ調整（アイコン、テキスト、ボタン）
  - ソートボタンとタグボタンのモバイル最適化
  - スクロールバーを隠すCSSユーティリティクラス追加
  - 全体的なモバイル体験の向上
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
Language: Japanese (user provides feedback in Japanese)
UI Preferences: Bottom navigation for main app views, hidden completed tasks
AI Features: OpenAI subtask generation in Japanese language
```