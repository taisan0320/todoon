import { users, tasks, tags, type User, type InsertUser, type Task, type InsertTask, type Tag, type InsertTag } from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  authenticateUser(username: string, password: string): Promise<User | null>;
  
  // Task management methods
  getTasks(userId: number): Promise<Task[]>;
  createTask(task: InsertTask, userId: number): Promise<Task>;
  updateTask(id: number, userId: number, updates: Partial<Omit<Task, 'id' | 'createdAt' | 'userId'>>): Promise<Task | undefined>;
  deleteTask(id: number, userId: number): Promise<boolean>;
  
  // Subtask management methods
  getSubtasks(parentTaskId: number, userId: number): Promise<Task[]>;
  createSubtask(subtask: InsertTask, userId: number): Promise<Task>;
  
  // Tag management methods
  getTags(): Promise<Tag[]>;
  createTag(tag: InsertTag): Promise<Tag>;
  updateTag(id: number, updates: Partial<Omit<Tag, 'id' | 'createdAt'>>): Promise<Tag | undefined>;
  deleteTag(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash the password before storing
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        password: hashedPassword,
      })
      .returning();
    return user;
  }

  async authenticateUser(username: string, password: string): Promise<User | null> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    if (!user) return null;
    
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) return null;
    
    return user;
  }

  async getTasks(userId: number): Promise<Task[]> {
    return await db.select().from(tasks)
      .where(and(eq(tasks.userId, userId), eq(tasks.isSubtask, false)))
      .orderBy(desc(tasks.createdAt));
  }

  async createTask(insertTask: InsertTask, userId: number): Promise<Task> {
    const [task] = await db
      .insert(tasks)
      .values({
        ...insertTask,
        userId,
      })
      .returning();
    return task;
  }

  async updateTask(id: number, userId: number, updates: Partial<Omit<Task, 'id' | 'createdAt' | 'userId'>>): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set(updates)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    return task || undefined;
  }

  async deleteTask(id: number, userId: number): Promise<boolean> {
    try {
      return await db.transaction(async (tx) => {
        // First delete all subtasks that reference this task
        await tx
          .delete(tasks)
          .where(and(eq(tasks.parentTaskId, id), eq(tasks.userId, userId)));
        
        // Then delete the main task
        const result = await tx
          .delete(tasks)
          .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
        
        return (result.rowCount || 0) > 0;
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      return false;
    }
  }

  async getSubtasks(parentTaskId: number, userId: number): Promise<Task[]> {
    return await db.select().from(tasks)
      .where(and(eq(tasks.parentTaskId, parentTaskId), eq(tasks.userId, userId)))
      .orderBy(asc(tasks.id));
  }

  async createSubtask(insertSubtask: InsertTask, userId: number): Promise<Task> {
    const [subtask] = await db
      .insert(tasks)
      .values({ 
        ...insertSubtask, 
        isSubtask: true,
        userId,
      })
      .returning();
    return subtask;
  }

  async getTags(): Promise<Tag[]> {
    return await db.select().from(tags).orderBy(asc(tags.name));
  }

  async createTag(insertTag: InsertTag): Promise<Tag> {
    const [tag] = await db
      .insert(tags)
      .values(insertTag)
      .returning();
    return tag;
  }

  async updateTag(id: number, updates: Partial<Omit<Tag, 'id' | 'createdAt'>>): Promise<Tag | undefined> {
    const [tag] = await db
      .update(tags)
      .set(updates)
      .where(eq(tags.id, id))
      .returning();
    return tag || undefined;
  }

  async deleteTag(id: number): Promise<boolean> {
    const result = await db.delete(tags).where(eq(tags.id, id));
    return (result.rowCount || 0) > 0;
  }


}

export const storage = new DatabaseStorage();
