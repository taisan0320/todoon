import { Session } from "express-session";
import { User } from "@shared/schema";

declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

export interface AuthenticatedRequest extends Express.Request {
  session: Session & {
    userId?: number;
  };
}