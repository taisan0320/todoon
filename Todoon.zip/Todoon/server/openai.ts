import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface SubtaskSuggestion {
  title: string;
  description?: string;
  estimatedTime?: string;
}

export async function generateSubtasks(taskTitle: string, taskTags: string[] = []): Promise<SubtaskSuggestion[]> {
  try {
    const tagsContext = taskTags.length > 0 ? ` (Tags: ${taskTags.join(', ')})` : '';
    
    const prompt = `
以下のタスクを3〜5個の実行可能なサブタスクに分解してください。各サブタスクは具体的で測定可能で達成可能である必要があります。

タスク: "${taskTitle}"${tagsContext}

サブタスクの配列を含むJSON形式で回答してください。各サブタスクには以下を含めてください：
- title: 明確で簡潔な行動項目（日本語）
- description: 何を行う必要があるかの簡単な説明（オプション、日本語）
- estimatedTime: おおよその時間見積もり（例：「30分」、「2時間」）（オプション、日本語）

回答はJSONのみで、以下の構造で返してください：
{
  "subtasks": [
    {
      "title": "サブタスクのタイトル",
      "description": "オプションの説明",
      "estimatedTime": "オプションの時間見積もり"
    }
  ]
}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "あなたは複雑なタスクをより小さく実行可能なサブタスクに分解するタスク管理アシスタントです。常に有効なJSONで回答してください。すべてのレスポンスは日本語で作成してください。"
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"subtasks": []}');
    return result.subtasks || [];
  } catch (error) {
    console.error("Error generating subtasks:", error);
    throw new Error("Failed to generate subtasks: " + (error as Error).message);
  }
}