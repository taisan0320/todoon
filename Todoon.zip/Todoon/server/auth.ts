import { Request, Response, NextFunction } from "express";
import { AuthenticatedRequest } from "./types";

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authReq = req as AuthenticatedRequest;
  
  if (!authReq.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  next();
}

export function getCurrentUserId(req: Request): number | null {
  const authReq = req as AuthenticatedRequest;
  return authReq.session.userId || null;
}